﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Mvc;
using prayerManagement.Models;


namespace prayerManagement.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        DataClasses1DataContext dc = new DataClasses1DataContext();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Display()
        {           
            return View(dc.prayers.ToList());
        }
        public ActionResult Edit()
        {
            return View(dc.prayers.ToList());
        }
        public ActionResult Add()
        {
            return View();
        }
        public ActionResult Add1()
        {

            string area = Request["Area"];
            string mosque = Request["mosque"];
            string address = Request["address"];
            string fajar = Request["fajar"];
            string zohar = Request["zohar"];
            string asar = Request["asar"];
            string magraib = Request["magraib"];
            string eisha = Request["Eisha"];
            string friday = Request["friday"];

            prayer p = new prayer();
            p.Area= area;
            p.mosque = mosque;
            p.address = address;
            p.fajar = fajar;
            p.zohar = zohar;
            p.asar = asar;
            p.magraib = magraib;
            p.Eisha = eisha;
            p.friday = friday;

            dc.prayers.InsertOnSubmit(p);
            dc.SubmitChanges();
           
            return RedirectToAction("Index");
        }
        public ActionResult display1()
        {
            string area = Request["val"];
            if (area.Equals("select"))
            {
                return RedirectToAction("/Display");

            }
            else
            {
                var a = from cust in dc.prayers
                        where cust.Area == area
                        select cust;
                return View(a);
            }
        }
        public ActionResult edit1()
        {
            string area = Request["val"];
            if (area.Equals("Select"))
            {
                return RedirectToAction("/Edit");

            }
            else {

                var a = from cust in dc.prayers
                        where cust.Area == area
                        select cust;

                return View(a);
            
            
            }
            
        }
        public ActionResult edit2(int id)
        {
            return View(dc.prayers.First(c=>c.Id==id));
        }
        public ActionResult editdone(int id)
        {
            var a = dc.prayers.First(s => s.Id == id);
            a.Area = Request["Area"];
            a.mosque = Request["mosque"];
            a.address = Request["address"];
            a.fajar = Request["fajar"];
            a.zohar = Request["zohar"];
            a.asar = Request["asar"];
            a.magraib = Request["magraib"];
            a.Eisha = Request["Eisha"];
            a.friday = Request["friday"];
            dc.SubmitChanges();                    
            return RedirectToAction("Index");

        }
        public ActionResult select()
        {
            return View(dc.prayers.ToList());
        }
        public ActionResult selectmosque()
        {            
            ViewBag.area = Request["val"];
            if (ViewBag.area.Equals("Select"))
            {
                return RedirectToAction("/select");

            }
            else
            {
                return View();
            }
        }
        public ActionResult mosquedd()
        {
            string area = Request["Area"];
            string mosque = Request["mosque"];
            string address = Request["address"];
            string fajar = Request["fajar"];
            string zohar = Request["zohar"];
            string asar = Request["asar"];
            string magraib = Request["magraib"];
            string eisha = Request["Eisha"];
            string friday = Request["friday"];
            

                prayer p = new prayer();
                p.Area = area;
                p.mosque = mosque;
                p.address = address;
                p.fajar = fajar;
                p.zohar = zohar;
                p.asar = asar;
                p.magraib = magraib;
                p.Eisha = eisha;
                p.friday = friday;

                dc.prayers.InsertOnSubmit(p);
                dc.SubmitChanges();

                return RedirectToAction("Index");
            
        }
        public ActionResult delete(int id)
        {
            var res = dc.prayers.First(c => c.Id == id);
            dc.prayers.DeleteOnSubmit(res);
            dc.SubmitChanges();
            return RedirectToAction("Index");            
        }
    }
}
